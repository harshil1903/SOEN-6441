//JUnit 4 test suite
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
@RunWith(Suite.class)
@SuiteClasses({TestJunit1.class, TestJunit2.class, TestJunit3.class, TestJunit4.class, TestJunit5.class})
public class JunitTestSuite {   
}  