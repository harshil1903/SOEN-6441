import java.util.Scanner;

/**
 * Driver class of the clock timer MVC example.
 */
public class MVCDemo extends Object {
	private DigitalClockView clockView;
	private ClockTimerModel clockModel;
	private ClockController clockController;

	/**
	 * Constructor that creates the model, view, and controller objects and calls
	 * the constructors that will connect them together.
	 */
	public MVCDemo() {
		clockModel = new ClockTimerModel();
		clockView = new DigitalClockView(clockModel);
		clockController = new ClockController(clockView, clockModel);
	};
  
	/**
	 * Starting point of the program. This is the only main method.
	 * 
	 * @param av: command-line parameters are not used by this program.
	 * @return none
	 */
	public static void main(String[] av) {
		MVCDemo od = new MVCDemo();
		od.demo();
	};

	/**
	 * Call the controller to start the interaction with the clock.
	 * 
	 * @return none
	 */
	public void demo() {
		clockController.controlClock();
		clockModel.detach(clockView); 
	};
};
