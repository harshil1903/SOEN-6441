/**
 * This is the Model class of the MVC trio for the clock timer example.
 */
class ClockTimerModel extends Observable {

	private int hour;
	private int minute;
	private int second;
	private int timedInterval;

	/**
	 * Returns the hour held by the clock.
	 * 
	 * @return hour held by the clock
	 */
	public int getHour() {
		return hour;
	};

	/**
	 * Returns the minute held by the clock.
	 * 
	 * @return minute held by the clock
	 */
	public int getMinute() {
		return minute;
	};

	/**
	 * Returns the second held by the clock.
	 * 
	 * @return second held by the clock
	 */
	public int getSecond() {
		return second;
	};

	/**
	 * Adds one second to the clock time.
	 * 
	 * @return none
	 */
	public void tick() {
		// update internal state
		second++;
		if (second >= 60) {
			minute++;
			second = 0;
			if (minute >= 60) {
				hour++;
				minute = 0;
				if (hour >= 24) {
					hour = 0;
				}
				;
			}
			;
		}
		;
		// specify that my state was changed
		// notify all attached Observers of a change
		notifyObservers(this);
	};

	/**
	 * Starts the clock and adds seconds for the set interval.
	 * 
	 * @return none
	 */
	public void start() {
		for (int i = 1; i <= timedInterval; i++)
			tick();
	};

	/**
	 * Set the starting time of the clock timer.
	 * 
	 * @param h: hour set on the clock timer
	 * @param m: minute set on the clock timer
	 * @param s: second set on the clock timer
	 */
	public void setTime(int h, int m, int s) {
		hour = h;
		minute = m;
		second = s;
		notifyObservers(this);
	}
 
	/**
	 * Set the timer interval of the clock timer.
	 * 
	 * @param t: number of seconds counted by the timer
	 */
	public void setTimedInterval(int t) {
		timedInterval = t;
	}
};
