/**
 * This is the View class of the MVC trio for the clock timer example.
 */
class DigitalClockView implements Observer {

	/**
	 * Constructor that attaches the model to the view.
	 * 
	 * @param clockModel
	 */
	public DigitalClockView(ClockTimerModel p_clockModel) {
		p_clockModel.attach(this);
	}
 
	/**
	 * Display the new hour, minute, second of the clock after the view has been
	 * notified of a state change in the model.
	 *
	 * @param obs: object that contains the information to be displayed
	 * @return none
	 */
	public void update(Observable p_o) {
		// redraw my clock�s reading after I was notified
		int hour = ((ClockTimerModel) p_o).getHour();
		int minute = ((ClockTimerModel) p_o).getMinute();
		int second = ((ClockTimerModel) p_o).getSecond();
		System.out.println(hour + ":" + minute + ":" + second);
	};
};
