import java.util.Scanner;

/**
 * This is the Controller class of the MVC trio for the clock timer example.
 */
public class ClockController {
 
	private DigitalClockView clockView;
	private ClockTimerModel clockModel;

	/**
	 * Constructor that connects the model, view, and controller together
	 * 
	 * @param newView:  the view to be connected to the controller
	 * @param newModel: the model to be connected to the controller
	 */
	public ClockController(DigitalClockView p_view, ClockTimerModel p_model) {
		clockView = p_view;
		clockModel = p_model;
	}

	/**
	 * Controls the user interaction, gets values from the user, and sends them to
	 * the model.
	 * 
	 * @return none
	 */
	public void controlClock() {
		Scanner kbd = new Scanner(System.in);
		while (true) {
			System.out.println("1. Set the timer's start time (1 int int int <return>)");
			System.out.println("2. Set the timer's timed interval (2 int <return>)");
			System.out.println("3. Start the timer (3 <return>)");
			System.out.println("4. Exit (4 <return>)");
			System.out.print("Enter action (1,2,3,4) : ");
			int command = kbd.nextInt();
			switch (command) {
			case 1:
				int h, m, s;
				h = kbd.nextInt();
				m = kbd.nextInt();
				s = kbd.nextInt();
				clockModel.setTime(h, m, s);
				break;
			case 2:
				int t;
				t = kbd.nextInt();
				clockModel.setTimedInterval(t);
				break;
			case 3:
				clockModel.start();
				break;
			case 4:
				kbd.close();
				System.out.println("Clock timer shutting down");
				return;
			}
		}
	};

}
