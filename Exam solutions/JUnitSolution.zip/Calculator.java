import java.util.Scanner;

public class Calculator {

	public enum operation {
		add, sub, mult, div
	};

	private double y;
	static Scanner keyboard;
	private double solution;
	private double x;

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	public void setSolution(double p_s) {
		solution = p_s; 
	}
	
	public double getSolution() {
		return solution; 
	}
	
	public Calculator() {
		solution = 0;
		keyboard = new Scanner(System.in);
	}

	public void addition(double x, double y) {
		setSolution(x + y);
	}

	public void subtraction(double x, double y) {
		setSolution(x - y);
	}

	public void multiplication(double x, double y) {
		setSolution(x * y);
	}

	public void division(double x, double y) {
		setSolution(x / y);
	}

	public static void main(String[] args) {
		Calculator calc = new Calculator();
		char another = 'n';
		System.out.println("initial value: ");
		calc.setX(Integer.parseInt(keyboard.next()));
		do {
			System.out.println("What operation? ('add', 'sub', 'mult', 'div')");
			operation ttt = operation.valueOf(keyboard.next());
			System.out.println("operand: ");
			calc.setY(keyboard.nextDouble());
			switch (ttt) {
			case add:
				calc.addition(calc.getX(), calc.getY());
				break;
			case sub:
				calc.subtraction(calc.getX(), calc.getY());
				break;
			case mult:
				calc.multiplication(calc.getX(), calc.getY());
				break;
			case div:
				calc.division(calc.getX(), calc.getY());
				break;
			}
			System.out.println("solution =" + calc.solution);
			calc.setX(calc.solution);
			System.out.print("continue (y/n)?");
			another = keyboard.next().charAt(0);
		} while (another == 'y');
	}
}