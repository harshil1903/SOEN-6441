import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CalculatorTestExpressions {

    Calculator calculator;

    @Before
    public void beforeEachTest(){
        calculator = new Calculator();
        calculator.setX(0);
        calculator.setY(0);
    }

    @Test
    public void testExpression1()
    {
        calculator.multiplication(3, 4);
        calculator.division(calculator.getSolution(), 6);
        calculator.subtraction(calculator.getSolution(), 2);
        calculator.addition(calculator.getSolution(), 2);
        assertEquals(2.0, calculator.getSolution(), 0.0001);
    }

    @Test
    public void testExpression2()
    {
        calculator.division(4, 2);
        calculator.multiplication(calculator.getSolution(), 3);
        calculator.addition(calculator.getSolution(), 2);
        assertEquals(8.0, calculator.getSolution(), 0.0001);
    }
}
