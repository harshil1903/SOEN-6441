import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CalculatorTestArith {
    Calculator calculator;

    @Before
    public void beforeEachTest(){
        calculator = new Calculator();
        calculator.setX(10);
        calculator.setY(2);
    }

    @Test
    public void testAddition()
    {
        calculator.addition(calculator.getX(),calculator.getY());
        assertEquals(12.0, calculator.getSolution(), 0.0001);
    }

    @Test
    public void testSubtraction()
    {
        calculator.subtraction(calculator.getX(),calculator.getY());
        assertEquals(8.0, calculator.getSolution(), 0.0001);
    }

    @Test
    public void testMultiplication()
    {
        calculator.multiplication(calculator.getX(),calculator.getY());
        assertEquals(20.0, calculator.getSolution(), 0.0001);
    }

    @Test
    public void testDivision()
    {
        calculator.division(calculator.getX(),calculator.getY());
        assertEquals(5.0, calculator.getSolution(), 0.0001);
    }

}
