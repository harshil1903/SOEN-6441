
public abstract class DFAstate {

    abstract public void transition(DFArunner p_DFArunner);

    abstract public char getInput();
}
