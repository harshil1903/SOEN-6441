public class SortStrategy {

    protected void sort(int[] p_array){
        System.out.println("No Sort");
    }
}
