import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * class that includes quicksort, mergesort and bubblesort
 */
class SortArray {
	private SorterType sorter;
	public enum SorterType {
		None, QuickSort, BubbleSort, MergeSort
	};

	//////////////////////////////
	// QUICKSORT IMPLEMENTATION //
	//////////////////////////////
	
	/**
	 * Function that calls the quicksort algorithm
	 */
	void quickSorter(int p[]) {
		System.out.println("QuickSort");
		quickSort(p, 0, p.length - 1);
	}

	/**
	 * Implementation of the quicksort algorithm
	 */
	void quickSort(int[] arr, int low, int high) {
		if (low < high) {

			// pi is partitioning index, arr[p]
			// is now at right place
			int pi = partition(arr, low, high);

			// Separately sort elements before
			// partition and after partition
			quickSort(arr, low, pi - 1);
			quickSort(arr, pi + 1, high);
		}
	}
	/**
	 * quicksort utility function
	 */
	void swap(int[] arr, int i, int j) {
		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
	}

	/**
	 * quicksort utility function
	 */
	int partition(int[] arr, int low, int high) {
		int pivot = arr[high];
		int i = (low - 1);
		for (int j = low; j <= high - 1; j++) {

			if (arr[j] < pivot) {
				i++;
				swap(arr, i, j);
			}
		}
		swap(arr, i + 1, high);
		return (i + 1);
	}

	///////////////////////////////
	// BUBBLESORT IMPLEMENTATION //
	///////////////////////////////
	
	/**
	 * BubbleSort algorithm implementation
	 */
	void bubbleSorter(int[] arr) {
		System.out.println("BubbleSort");
		int n = arr.length;
		int temp = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 1; j < (n - i); j++) {
				if (arr[j - 1] > arr[j]) {
					// swap elements
					temp = arr[j - 1];
					arr[j - 1] = arr[j];
					arr[j] = temp;
				}

			}
		}
	}

	///////////////////////////////
	// MERGE SORT IMPLEMENTATION //
	///////////////////////////////
	
	/**
	 * Function that calls the recursive mergesort algorithm implementation
	 */
	void mergeSorter(int[] p) {
		System.out.println("MergeSort");
		mergeSort(p, p.length);
	}

	/**
	 * Recursive mergesort algorithm implementation
	 */
	void mergeSort(int[] a, int n) {
		if (n < 2) {
			return;
		}
		int mid = n / 2;
		int[] l = new int[mid];
		int[] r = new int[n - mid];

		for (int i = 0; i < mid; i++) {
			l[i] = a[i];
		}
		for (int i = mid; i < n; i++) {
			r[i - mid] = a[i];
		}
		mergeSort(l, mid);
		mergeSort(r, n - mid);

		merge(a, l, r, mid, n - mid);
	}

	
	/**
	 * Utility function of the mergesort algorithm
	 */
	static void merge(int[] a, int[] l, int[] r, int left, int right) {

		int i = 0, j = 0, k = 0;
		while (i < left && j < right) {
			if (l[i] <= r[j]) {
				a[k++] = l[i++];
			} else {
				a[k++] = r[j++];
			}
		}
		while (i < left) {
			a[k++] = l[i++];
		}
		while (j < right) {
			a[k++] = r[j++];
		}
	}

	///////////////////////////////
	// GENERAL UTILITY FUNCTIONS //
	///////////////////////////////
	
	public void setSorter(int answer) {
		switch (answer) {
		case 1:
			sorter = SorterType.QuickSort;
			break;
		case 2:
			sorter = SorterType.BubbleSort;
			break;
		case 3:
			sorter = SorterType.MergeSort;
			break;
		default:
			sorter = SorterType.None;
		}
	}

	public void sort(int[] arr) {
		switch (sorter) {
		case QuickSort:
			quickSorter(arr);
			break;
		case MergeSort:
			mergeSorter(arr);
			break;
		case BubbleSort:
			bubbleSorter(arr);
			break;
		case None:
			System.out.println("NoSort");
			break;
		default:
			break;
		}
	}

	public void readFromFile(int[] arr) {
		int index = 0;
		Scanner scanner;

		try {
			scanner = new Scanner(new File("numbers.txt"));
		} catch (FileNotFoundException e) {
			System.out.println("File cannot be opened. Aborting.");
			return;
		}
		while (scanner.hasNext()) {
			if (scanner.hasNextInt()) {
				arr[index] = scanner.nextInt();
			} else {
				scanner.next();
			}
			index++;
		}
		scanner.close();
	}
	
	void printArray(int[] arr, int size) {
		for (int i = 1; i <= size; i++) {
			System.out.print(arr[i - 1] + " ");
			if (i % 5 == 0)
				System.out.println();
		}
		System.out.println();
	}
}
