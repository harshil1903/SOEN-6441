import java.util.Scanner;

public class StateABCDriver {
	
	static Scanner kbd = new Scanner(System.in);
	
	enum DFAstate {
		Start, A, B, C, D, Stop
		};

	DFAstate state = DFAstate.Start;

	public static void main(String[] args) {
		StateABCDriver abcDFA = new StateABCDriver();
		abcDFA.run();
	}

	public char getInput() {
		char value; 
		value = kbd.next().charAt(0);
		return value; 
	}
	
	void run() {
		char input; 
		do {
			switch (state) {
			case Start:
				System.out.println("Start. State A");
				state = DFAstate.A;
			case A:
				System.out.println("Now in state A. Options: [a,b,c]");
				input = getInput();
				switch (input) {
				case 'a':
					state = DFAstate.A;
					break;			
				case 'b':
					state = DFAstate.B;
					break;
				case 'c':
					state = DFAstate.C;
					break;
				default:
					System.out.println("invalid transition");
					break;
				}
				break;
			case B:
				System.out.println("Now in state B. Options: [a]");
				input = getInput();
				switch (input) {
				case 'a':
					state = DFAstate.A;
					break;
				default:
					System.out.println("invalid transition");
					break;
				}
				break;
			case C:
				System.out.println("Now in state C. Options: [b,d]");
				input = getInput();
				switch (input) {
				case 'b':
					state = DFAstate.B;
					break;
				case 'd':
					state = DFAstate.D;
					break;
				default:
					System.out.println("invalid transition");
					break;
				}
				break;
			case D:
				System.out.println("Now in state D. Final state.");
				state = DFAstate.Stop; 
				return; 
			default:
				System.out.println("invalid state");
			}
		} while (true);

	}
}
