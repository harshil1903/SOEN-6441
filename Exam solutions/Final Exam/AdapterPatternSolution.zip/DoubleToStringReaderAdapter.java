import java.util.LinkedList;

public class DoubleToStringReaderAdapter extends StringReader {

    public DoubleReader d_doubleReader;

    public DoubleToStringReaderAdapter()
    {
        d_doubleReader = new DoubleReader();
    }

    public LinkedList<String> read_kbd()
    {
        LinkedList<Double> temp = d_doubleReader.read_double();
        return  translate(temp);
    }

    public LinkedList<String> translate(LinkedList<Double> p_myDoubles)
    {

        LinkedList<String> l_myStrings = new LinkedList<>();
        System.out.println("Inside translate");
        for(Double d : p_myDoubles)
        {
            l_myStrings.add(d.toString() + " ");
        }

        return l_myStrings;
    }

}
