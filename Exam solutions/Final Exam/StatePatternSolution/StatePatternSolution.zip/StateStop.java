import java.util.Scanner;

public class StateStop extends StateD {

    public void transition(DFArunner p_DFArunner)
    {
        System.out.println("Unreachable");
    }

}
