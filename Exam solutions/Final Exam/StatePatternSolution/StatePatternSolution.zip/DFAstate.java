
public abstract class DFAstate {

    abstract public void transition(DFArunner p_DFArunner);

}
