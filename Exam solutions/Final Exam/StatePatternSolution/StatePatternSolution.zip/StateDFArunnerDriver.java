public class StateDFArunnerDriver {

	public static void main(String[] args) {
		DFArunner runner = new DFArunner();
		runner.run();
	}
}
